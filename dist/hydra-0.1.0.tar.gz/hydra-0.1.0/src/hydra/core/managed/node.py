from .internal/nodeConfig import NodeConfig
from .internal/nodeState import NodeState
from .internal/nodeRuntimeState import NodeRuntimeState

class ManagedNode:
    def __init__(self, config: NodeConfig):
        self.config: NodeConfig = config
        self.state: NodeRuntimeState = NodeRuntimeState(name=config.nodeName)
        
